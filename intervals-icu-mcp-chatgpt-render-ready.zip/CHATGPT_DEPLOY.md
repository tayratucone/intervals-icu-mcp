# Deploy to ChatGPT

This fork keeps the original stdio server intact in `intervals_icu_mcp.server`
and adds an HTTP entry point for ChatGPT connectors:

```text
python -m intervals_icu_mcp.chatgpt_server
```

Environment variables:

```text
INTERVALS_ICU_API_KEY=...
INTERVALS_ICU_ATHLETE_ID=i636217
MCP_PATH=/mcp-loic-intervals-icu-7c42
HOST=0.0.0.0
PORT=8080
```

After deployment, the ChatGPT connector URL is:

```text
https://YOUR-HOST/mcp-loic-intervals-icu-7c42
```
