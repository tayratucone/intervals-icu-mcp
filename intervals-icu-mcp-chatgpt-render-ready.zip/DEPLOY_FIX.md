# Render deploy fix

If Render logs show:

```text
Transport: STDIO
Starting MCP server 'Intervals.icu' with transport 'stdio'
Application exited early
```

then Render is deploying the original upstream repository, not this ChatGPT-ready version.

This fork must contain:

```text
src/intervals_icu_mcp/chatgpt_server.py
```

and the Dockerfile must end with:

```dockerfile
ENTRYPOINT ["python", "-m", "intervals_icu_mcp.chatgpt_server"]
```

Expected successful logs should mention HTTP transport and a URL/port, not STDIO.

Render environment variables:

```text
INTERVALS_ICU_API_KEY=your Intervals.icu API key
INTERVALS_ICU_ATHLETE_ID=i636217
MCP_PATH=/mcp-loic-intervals-icu-7c42
HOST=0.0.0.0
PORT=8080
```

ChatGPT connector URL:

```text
https://YOUR-RENDER-HOST/mcp-loic-intervals-icu-7c42
```
